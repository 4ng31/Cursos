%KNN_letter Summary of this scriptt goes here
%   1: Load letter.mat file which contains letter data and its label
%      seperately. 
%   2: Randomize the order of data for each iternation so that new sets of
%      training and test data are formed.
%     
%      The training data is of having size of Nxd where N is the number of
%      measurements and d is the number of variables of the training data.
%  
%      Similarly the size of the test data is Mxd where M is the number of
%      measurements and d is the number of variables of the test data.

%   3: For each observation in test data, we compute the euclidean distance
%      from each obeservation in training data.
%   4: We evalutate 'k' nearest neighbours among them and store it in an
%      array.
%   5: We apply the label for which distance is minimum
%       5.1: In case of a tie, we randomly label the class.
%   6: Return the class label.
%   7: Compute confusion matrix.
%----------------Program Code starts below--------------------------


clear all;
clc;

% Step 1
load letter.mat;
k=input('Enter the number of nearest neighbors:  ');
%Step 2: Randomizing and dividing data into 1:1 ratio for training and
%testing

split=0;
count=0;
while(count~=1)
    numofobs=length(letterdata);
    rearrangement= randperm(numofobs);
    newletterdata=letterdata(rearrangement,:);
    newletterlabel=letterlabel(rearrangement);
    split = ceil(numofobs/2);
    count=count+1;
end
lettertrainingdata = newletterdata(1:split,:);
lettertraininglabel = newletterlabel(1:split);
lettertestdata = newletterdata(split+1:end,:);
originallabel = newletterlabel(split+1:end);

numoftestdata = size(lettertestdata,1);
numoftrainingdata = size(lettertrainingdata,1);

for sample=1:numoftestdata
    %Step 3: Computing euclidean distance for each testdata
    euclideandistance = sum((repmat(lettertestdata(sample,:),numoftrainingdata,1)-lettertrainingdata).^2,2);
        
    %Step 4: compute k nearest neighbors and store them in an array
    [dist position] = sort(euclideandistance,'ascend');
    nearestneighbors=position(1:k);
    nearestdistances=dist(1:k);
    
    % Step 5: We apply the label for which distance is minimum
            %Step 5.1: In case of a tie, we randomly label the class.
    if(nearestdistances(1)<nearestdistances(2))
        lettertestlabel(sample)=lettertraininglabel(position(1));
    end
    
    if (nearestdistances(1)==nearestdistances(2)&&nearestdistances(1)<nearestdistances(3))
            index=randi(2,1,1);
            lettertestlabel(sample)=lettertraininglabel(position(index));
    end
        
    if (nearestdistances(1)==nearestdistances(2)&&nearestdistances(2)==nearestdistances(3)&&nearestdistances(3)<nearestdistances(4))
            index=randi(3,1,1);
            lettertestlabel(sample)=lettertraininglabel(position(index));
    end
        
    if (nearestdistances(1)==nearestdistances(2)&&nearestdistances(2)==nearestdistances(3)&&nearestdistances(3)==nearestdistances(4))
            index=randi(4,1,1);
            lettertestlabel(sample)=lettertraininglabel(position(index));
    else
            index=randi(k,1,1);
            lettertestlabel(sample)=lettertraininglabel(position(index));
    end
end

%Step 7: Confusion Matrix
originallabel=originallabel';
[confmat order]=confusionmat(originallabel,lettertestlabel)
accuracy=(sum(diag(confmat)))/sum(sum(confmat));