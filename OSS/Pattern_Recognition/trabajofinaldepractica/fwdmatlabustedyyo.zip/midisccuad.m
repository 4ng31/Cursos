function [labels]=midisccuad(Xtrain_total,Ytrain_total,Xtest)
    
features=length(Xtrain_total(1,:));
clases=unique(Ytrain_total); %Identifica las clases
cant_clases=length(clases); % Cuenta cu�ntas clases hay
ntest=length(Xtest);
ntrain=length(Xtrain_total);

Prob_a_priori=NaN(cant_clases,1);

    for i=1:cant_clases;

        Prob_a_priori(i)=length(find(Ytrain_total==clases(i)))/ntrain;

    end

Medias_clase=zeros(cant_clases,features);
Xtrain_clases=NaN(ntrain,features,cant_clases);

for i=1:ntrain

    Xtrain_clases(i,:,clases==Ytrain_total(i))=Xtrain_total(i,:);
    
end

Cov_clase=zeros(features,features,cant_clases);

for i=1:cant_clases
    for j=1:features
        Medias_clase(i,j)=nanmean(Xtrain_clases(:,j,i));
    end
    Cov_clase(:,:,i)=nancov(Xtrain_clases(:,:,i));%Esto lo usaremos para el discriminante cuadr�tico
end


prob_clases_cuad=NaN(ntest,cant_clases);

for i_test=1:ntest
    for i_clase=1:cant_clases
    prob_clases_cuad(:,i_clase)=mvnpdf(Xtest,Medias_clase(i_clase,:),Cov_clase(:,:,i_clase));
    end
end

labels=(prob_clases_cuad(:,1)./prob_clases_cuad(:,2))*(Prob_a_priori(1)/Prob_a_priori(2));

for i=1:ntest

    if labels(i)>=1
        labels(i)=clases(1);
    else
        labels(i)=clases(2);
    end
end

end