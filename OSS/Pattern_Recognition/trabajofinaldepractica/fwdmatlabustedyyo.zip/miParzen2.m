function [labels_parzen]=miParzen2(Xtrain_res,Ytrain_res,Xval,SigmaParzen)
                         
    nvalparzen=length(Xval(:,1));
    ntrainparzen=length(Xtrain_res(:,1));

    clases=unique(Ytrain_res);%Define las clases posibles

    labels_parzen=NaN(nvalparzen,1);
    clasif_parzen=zeros(nvalparzen,length(clases));

    for ival=1:nvalparzen;

        for itrain=1:ntrainparzen;

              clase_actual=find(clases==Ytrain_res(itrain));

                clasif_parzen(ival, clase_actual)=clasif_parzen(ival, clase_actual)+(1/(2*pi()*SigmaParzen^2)^(0.5))*exp(-(norm(Xtrain_res(itrain,:)-Xval(ival,:)))/(2*SigmaParzen^2));

            
        end

        [~,clasepreponderante]=max(clasif_parzen(ival,:));

        labels_parzen(ival)=clases(clasepreponderante);
    end


