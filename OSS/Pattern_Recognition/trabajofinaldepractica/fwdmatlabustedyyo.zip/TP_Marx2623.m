%% Trabajo pr�ctico OS14 - Nicol�s Marx
clc
clear all
close all

load datosOS14.mat %Cargo los datos
Xorig=datos.X;
Yorig=datos.Y;
clear datos %Libero memoria
total_datos=length(Yorig);
filename='Resultados_TP_Marx_r.02.xlsx';

%% Resultados solicitados
iteraciones_solicitadas=10;
Vec_TP_knn_error_pred=NaN(iteraciones_solicitadas,1);
Vec_TP_knn_Koptim=NaN(iteraciones_solicitadas,1);
Vec_TP_parzen_error_pred=NaN(iteraciones_solicitadas,1);
Vec_TP_parzen_SimaOptim=NaN(iteraciones_solicitadas,1);
Vec_TP_disc_lin_error_pred=NaN(iteraciones_solicitadas,1);
Vec_TP_disc_cuad_error_pred=NaN(iteraciones_solicitadas,1);
Vec_TP_SVM_error_pred=NaN(iteraciones_solicitadas,1);
Vec_TP_SVM_Copt=NaN(iteraciones_solicitadas,1);
Vec_TP_SVM_ParamKernelOptim=NaN(iteraciones_solicitadas,1);

Vec_TP_knn_error_pred_KPCA=NaN(iteraciones_solicitadas,1);
Vec_TP_knn_Koptim_KPCA=NaN(iteraciones_solicitadas,1);
Vec_TP_parzen_error_pred_KPCA=NaN(iteraciones_solicitadas,1);
Vec_TP_parzen_SimaOptim_KPCA=NaN(iteraciones_solicitadas,1);
Vec_TP_disc_lin_error_pred_KPCA=NaN(iteraciones_solicitadas,1);
Vec_TP_disc_cuad_error_pred_KPCA=NaN(iteraciones_solicitadas,1);
Vec_TP_SVM_error_pred_KPCA=NaN(iteraciones_solicitadas,1);
Vec_TP_SVM_Copt_KPCA=NaN(iteraciones_solicitadas,1);
Vec_TP_SVM_ParamKernelOptim_KPCA=NaN(iteraciones_solicitadas,1);

Vec_TP_knn_error_val=NaN(iteraciones_solicitadas,1);
Vec_TP_parzen_error_val=NaN(iteraciones_solicitadas,1);
Vec_TP_SVM_error_val=NaN(iteraciones_solicitadas,1);

Vec_TP_lambda_KPCA=NaN(iteraciones_solicitadas,total_datos);

Vec_TP_knn_error_val_KPCA=NaN(iteraciones_solicitadas,1);
Vec_TP_parzen_error_val_KPCA=NaN(iteraciones_solicitadas,1);
Vec_TP_SVM_error_val_KPCA=NaN(iteraciones_solicitadas,1);



valoresn_train=[80 120 150 total_datos];


for iter_tam_ntrain=1:length(valoresn_train)
    tic
    ntrain=valoresn_train(iter_tam_ntrain);
    
    
    
for iter_TP=1:iteraciones_solicitadas
    avance=['Iteraci�n ',num2str(iter_TP+(iter_tam_ntrain-1)*iteraciones_solicitadas),' de ',num2str(iteraciones_solicitadas*length(valoresn_train))];
    display(avance);
%% <<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>
%                  Pre/procesamiento de datos
%<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
   
idx_n_train=randperm(length(Yorig(:,1)),ntrain);%Selecciono al azar los datos para entrenamiento

Xtrain_orig=Xorig(idx_n_train,:);%Genero el vector de entrenamiento

[Xtrain_norm,Xnomr_max,Xnorm_min]=minormalizador(Xtrain_orig);%Normalizo los datos de entrenamiento

Ytrain_total=Yorig(idx_n_train);

Xtest_orig=Xorig;%Genero el vector de testeo
Xtest_orig(idx_n_train,:)=[];

[Xtest,~,~]=minormalizador(Xtest_orig,Xnomr_max,Xnorm_min);%Aplico a los datos de test la transformaci�n que hab�a aplicado a los de entrenamiento.
Ytest=Yorig;
Ytest(idx_n_train)=[];

ntest=length(Xtest);

nval=10; %Defino el tama�o de la partici�n de validaci�n.

features=length(Xtrain_norm(1,:));
clases=unique(Ytrain_total); %Identifica las clases

cant_clases=length(clases); % Cuenta cu�ntas clases hay
disp('Fin preprocesamient de datos');
%######################################################################
%Hasta ac� es homog�neo para todos los clasificadores, lo que permite 
%asegurar que no habr� diferencias ente los clasificadores por tomar  
%diferentes datos de la muestra o distintas particiones de validaci�n.
%######################################################################

%% <<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>
%                  Clasificador KNN
%<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

error_knn_k=NaN(ntrain,2);% Guardaremos el error medio y el std dsv para cada K.

for k=cant_clases+1:cant_clases:ntrain % prueba los diferentes valores de K
    
    error_val_knn=NaN(ntrain/nval,1); %Error en cada partici�n de validaci�n
    indice_particion=0;
    
        for idx_val=1:nval:ntrain; % Alterna la partici�n de validaci�n
                indice_particion=1+indice_particion;
            
                idx_val_min=idx_val;
                idx_val_max=idx_val+nval-1;
                rango_val=idx_val_min:idx_val_max;%Define el rango de validaci�n
                            
                % Ahora reparte los valores de Xtrain entre validaci�n y train restante
             
                Xval=Xtrain_norm(rango_val,:);
                Yval=Ytrain_total(rango_val);
                
                Xtrain_res=Xtrain_norm;
                Xtrain_res(rango_val,:)=[];
                Ytrain_res=Ytrain_total;
                Ytrain_res(rango_val,:)=[]; 
                
                labels_knn=NaN(nval,1);

                labels_knn(:,1)=miKNN2(Xtrain_res,Ytrain_res,Xval,k);%Clasifica los datos de validaci�n
                
                vec_diferencias_val_knn=labels_knn(:,1)-Yval(:);
                diferencias_knn=length(find(vec_diferencias_val_knn~=0));
                error_val_knn(indice_particion,1)=diferencias_knn/nval; %Calcula la tasa de error para esta partici�n de validaci�n
                                                     
end
      
        error_knn_k(k,1)=mean(error_val_knn(:,1)); %Calcula el error medio para este valor de K
        error_knn_k(k,2)=std(error_val_knn(:,1));  %Calcula el std desv del error para este valor de K
        
    end
          
  
[Error_knn_mean,K_optim]=min(error_knn_k(:,1)); %Define el K �ptimo como el del menor error medio

%Error_knn_std=error_knn_k(K_optim,2);

Vec_TP_knn_error_val(iter_TP,1)=Error_knn_mean;

Vec_TP_knn_Koptim(iter_TP,1)=K_optim;

 %Testea el clasificador
if ~isempty(Ytest(:))
    labels_test_knn=miKNN2(Xtrain_norm,Ytrain_total,Xtest,K_optim);
    
    vec_diferencias_test_knn=labels_test_knn(:)-Ytest(:);
    diferencias_test_knn=length(find(vec_diferencias_test_knn~=0));
    error_test_knn=diferencias_test_knn/ntest; 
    Vec_TP_knn_error_pred(iter_TP,1)=error_test_knn;

    else if ntrain==total_datos
        
    Vec_TP_knn_error_pred(iter_TP,1)=Error_knn_mean;
        end
end
    
disp('Fin Clasifador KNN');


%}

%% <<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>
%                  Clasificador de Parzen
%<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


SigmaParzen=0; 
SigmaParzenmax=1.5;
iteraciones_optim_Parzen=15;
error_parzen_k=NaN(iteraciones_optim_Parzen,3);


for k=1:iteraciones_optim_Parzen 
    
    SigmaParzen=SigmaParzen+SigmaParzenmax/iteraciones_optim_Parzen; % Va aumentando el valor de sigma en cada iteraci�n
    
    error_val_parzen=NaN(ntrain/nval,1);%Error en cada partici�n de validaci�n
    
    indice_particion=0;
    
      for idx_val=1:nval:ntrain; %Alterna la partici�n de validaci�n
          indice_particion=indice_particion+1;
                idx_val_min=idx_val;
                idx_val_max=idx_val+nval-1;
                rango_val=idx_val_min:idx_val_max;%Define el rango de validaci�n
                            
                % Ahora reparte los valores de Xtrain entre validaci�n y train restante
                       
                Xval=Xtrain_norm(rango_val,:);
                Yval=Ytrain_total(rango_val);
                
                Xtrain_res=Xtrain_norm;
                Xtrain_res(rango_val,:)=[];
                Ytrain_res=Ytrain_total;
                Ytrain_res(rango_val,:)=[];
                
                [labels_parzen]=miParzen2(Xtrain_res,Ytrain_res,Xval,SigmaParzen);
                               
                vec_diferencias_val_parzen=labels_parzen(:,1)-Yval(:);
                diferencias_parzen=length(find(vec_diferencias_val_parzen~=0));
                error_val_parzen(indice_particion,1)=diferencias_parzen/nval;
                                    
      end
      
        error_parzen_k(k,1)=mean(error_val_parzen(:,1));
        error_parzen_k(k,2)=std(error_val_parzen(:,1)); 
        error_parzen_k(k,3)=SigmaParzen;
    end
 
  
[Error_parzen_mean,koptim]=min(error_parzen_k(:,1));
%Error_Parzen_Std=error_parzen_k(koptim,2);
Sigma_optimo_parzen=error_parzen_k(koptim,3);

Vec_TP_parzen_error_val(iter_TP,1)=Error_parzen_mean;

Vec_TP_parzen_SimaOptim(iter_TP,1)=Sigma_optimo_parzen;

if ~isempty(Ytest(:))
    
    labels_test_parzen=miParzen2(Xtrain_norm,Ytrain_total,Xtest,Sigma_optimo_parzen);
    vec_diferencias_test_parzen=labels_test_parzen(:)-Ytest(:);
    diferencias_test_parzen=length(find(vec_diferencias_test_parzen~=0));
    error_test_parzen=diferencias_test_parzen/ntest; 
    
    Vec_TP_parzen_error_pred(iter_TP,1)=error_test_parzen;

else if ntrain==total_datos   

    Vec_TP_parzen_error_pred(iter_TP,1)=Error_parzen_mean;

    end
end

disp('Fin Clasifador Parzen');

    
    %}

%% <<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>
%                  Clasificador de Bayes
%<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


%---------------------
%Discriminante lineal
%---------------------

if ~isempty(Ytest(:))

    labels_disc_lineal=midisclin(Xtrain_norm,Ytrain_total,Xtest);
    vec_diferencias_test_disc_lineal=labels_disc_lineal(:)-Ytest(:);
    diferencias_test_disc_lineal=length(find(vec_diferencias_test_disc_lineal~=0));
    error_test_disc_lineal=diferencias_test_disc_lineal/ntest; 
  
    Vec_TP_disc_lin_error_pred(iter_TP,1)=error_test_disc_lineal;

else if ntrain==total_datos
      
    labels_disc_lineal=midisclin(Xtrain_norm,Ytrain_total,Xtrain_norm);
    vec_diferencias_test_disc_lineal=labels_disc_lineal(:)-Ytrain_total(:);
    diferencias_test_disc_lineal=length(find(vec_diferencias_test_disc_lineal~=0));
    error_test_disc_lineal=diferencias_test_disc_lineal/ntrain; 
  
    Vec_TP_disc_lin_error_pred(iter_TP,1)=error_test_disc_lineal;
        
    end
end
    
%---------------------
%Discriminante cuadr�tico
%---------------------
if ~isempty(Ytest(:))
    
        labels_disc_cuad=midisccuad(Xtrain_norm,Ytrain_total,Xtest);

        vec_diferencias_test_disc_cuad=labels_disc_cuad(:)-Ytest(:);
        diferencias_test_disc_cuad=length(find(vec_diferencias_test_disc_cuad~=0));
        error_test_disc_cuad=diferencias_test_disc_cuad/ntest; 

        Vec_TP_disc_cuad_error_pred(iter_TP,1)=error_test_disc_cuad;

else if ntrain==total_datos
        
        labels_disc_cuad=midisccuad(Xtrain_norm,Ytrain_total,Xtrain_norm);

        vec_diferencias_test_disc_cuad=labels_disc_cuad(:)-Ytrain_total(:);
        diferencias_test_disc_cuad=length(find(vec_diferencias_test_disc_cuad~=0));
        error_test_disc_cuad=diferencias_test_disc_cuad/ntrain; 

        Vec_TP_disc_cuad_error_pred(iter_TP,1)=error_test_disc_cuad;
   
    end
end
disp('Fin Clasifador Bayes');


%}
%% <<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>
%                  Clasificador SVM
%<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


tipoKernel='gaussiano';

C=0; %Define los rangos a evaluar de los par�metros C y "Par�metro del Kernel" 
Cmax=2;
paramKernel=0;
paramKernelmax=2.5;
iteraciones_optim_SVM=10;
total_iteraciones=iteraciones_optim_SVM*iteraciones_optim_SVM;

error_SVM_param_costo=NaN(ntrain,ntrain,2);

for param=1:iteraciones_optim_SVM % Loop de optimizaci�n de paramKernel

    paramKernel=paramKernel+paramKernelmax/ntrain;
    
    for costo=1:iteraciones_optim_SVM % Loop de optimizaci�n de C
        iteracion=iteraciones_optim_SVM*(param-1)+costo;
        C=C+Cmax/ntrain; % Va aumentando el valor de sigma en cada iteraci�n

        error_val_SVM=NaN(ntrain/nval,1);%Error en cada partici�n de validaci�n

        indice_particion=0;

          for idx_val=1:nval:ntrain; %Alterna la partici�n de validaci�n
              indice_particion=indice_particion+1;
                    idx_val_min=idx_val;
                    idx_val_max=idx_val+nval-1;
                    rango_val=idx_val_min:idx_val_max;%Define el rango de validaci�n

                    % Ahora reparte los valores de Xtrain entre validaci�n y train restante

                    Xval=Xtrain_norm(rango_val,:);
                    Yval=Ytrain_total(rango_val);

                    Xtrain_res=Xtrain_norm;
                    Xtrain_res(rango_val,:)=[];
                    Ytrain_res=Ytrain_total;
                    Ytrain_res(rango_val,:)=[];
                    
                    labels_svm=miSVM2(Xtrain_res,Ytrain_res,Xval,tipoKernel,paramKernel,C);
                   
                    
                    vec_diferencias_val_SVM=labels_svm(:,1)-Yval(:);
                    diferencias_SVM=length(find(vec_diferencias_val_SVM~=0));
                    error_val_SVM(indice_particion,1)=diferencias_SVM/nval;

          end

            error_SVM_param_costo(param,costo,1)=mean(error_val_SVM(:,1));
            error_SVM_param_costo(param,costo,2)=std(error_val_SVM(:,1));
   % fprintf('Iteraci�n: ',iteracion,' de ',total_iteraciones),
    end
end

[~,columna_optim]=min(min(error_SVM_param_costo(:,:,1)));
[~,fila_optim]=min(min(error_SVM_param_costo(:,:,1),[],2));

Error_SVM_optim=error_SVM_param_costo(fila_optim,columna_optim,1);
%Error_SVM_optim_StdDesv=error_SVM_param_costo(fila_optim,columna_optim,2);

    C_optimo=Cmax/iteraciones_optim_SVM*columna_optim;
    Param_kernel_optim=paramKernelmax/iteraciones_optim_SVM*fila_optim;
    Vec_TP_SVM_Copt(iter_TP,1)=C_optimo;
    Vec_TP_SVM_ParamKernelOptim(iter_TP,1)=Param_kernel_optim; 

    Vec_TP_SVM_error_val(iter_TP,1)=Error_SVM_optim;

  
if ~isempty(Ytest(:))
    
    labels_test_SVM=miSVM2(Xtrain_norm,Ytrain_total,Xtest,tipoKernel,Param_kernel_optim,C_optimo);
        
    vec_diferencias_test_SVM=labels_test_SVM(:)-Ytest(:);
    diferencias_test_SVM=length(find(vec_diferencias_test_SVM~=0));
    error_test_SVM=diferencias_test_SVM/ntest; 

    Vec_TP_SVM_error_pred(iter_TP,1)=error_test_SVM;
else if ntrain==total_datos
        
     Vec_TP_SVM_error_pred(iter_TP,1)=Error_SVM_optim;
    end
end


disp('Fin Clasifador SVM');
 
    
    %}
    
%% <<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>
%                  KPCA
%<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

tipoKernelPCA='gaussiano';
paramPCA=0.5;
dim_proyeccion=2;
[Xtest_KPCA,Xtrain_KPCA,lambda] = miKPCA(Xtrain_norm,tipoKernelPCA,paramPCA,dim_proyeccion,Xtest);

disp('Fin proyecci�n KPCA');

Vec_TP_lambda_KPCA(iter_TP,1:10)=lambda(1:10);

%}

%% <<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>
%                  Clasificador KNN con KPCA
%<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

error_knn_k_KPCA=NaN(ntrain,2);% Guardaremos el error medio y el std dsv para cada K.

for k=cant_clases+1:cant_clases:ntrain % prueba los diferentes valores de K
    
    error_val_knn_KPCA=NaN(ntrain/nval,1); %Error en cada partici�n de validaci�n
    indice_particion=0;
    
        for idx_val=1:nval:ntrain; % Alterna la partici�n de validaci�n
                indice_particion=1+indice_particion;
            
                idx_val_min=idx_val;
                idx_val_max=idx_val+nval-1;
                rango_val=idx_val_min:idx_val_max;%Define el rango de validaci�n
                            
                % Ahora reparte los valores de Xtrain entre validaci�n y train restante
             
                Xval=Xtrain_KPCA(rango_val,:);
                Yval=Ytrain_total(rango_val);
                
                Xtrain_res=Xtrain_KPCA;
                Xtrain_res(rango_val,:)=[];
                Ytrain_res=Ytrain_total;
                Ytrain_res(rango_val,:)=[]; 
                
                labels_knn_KPCA=NaN(nval,1);

                labels_knn_KPCA(:,1)=miKNN2(Xtrain_res,Ytrain_res,Xval,k);%Clasifica los datos de validaci�n
                
                vec_diferencias_val_knn=labels_knn_KPCA(:,1)-Yval(:);
                diferencias_knn=length(find(vec_diferencias_val_knn~=0));
                error_val_knn_KPCA(indice_particion,1)=diferencias_knn/nval; %Calcula la tasa de error para esta partici�n de validaci�n
                                                     
      end
      
        error_knn_k_KPCA(k,1)=mean(error_val_knn_KPCA(:,1)); %Calcula el error medio para este valor de K
        error_knn_k_KPCA(k,2)=std(error_val_knn_KPCA(:,1));  %Calcula el std desv del error para este valor de K
        
    end
          
  
[Error_knn_mean_KPCA,K_optim_KPCA]=min(error_knn_k_KPCA(:,1)); %Define el K �ptimo como el del menor error medio

%Error_knn_std_KPCA=error_knn_k_KPCA(K_optim_KPCA,2);

Vec_TP_knn_Koptim_KPCA(iter_TP,1)=K_optim_KPCA;

Vec_TP_knn_error_val_KPCA(iter_TP,1)=Error_knn_mean_KPCA;


 %Testea el clasificador

if ~isempty(Ytest(:))
    labels_test_knn_KPCA=miKNN2(Xtrain_KPCA,Ytrain_total,Xtest_KPCA,K_optim_KPCA);
    
    vec_diferencias_test_knn_KPCA=labels_test_knn_KPCA(:)-Ytest(:);
    diferencias_test_knn_KPCA=length(find(vec_diferencias_test_knn_KPCA~=0));
    error_test_knn_KPCA=diferencias_test_knn_KPCA/ntest; 

    Vec_TP_knn_error_pred_KPCA(iter_TP,1)=error_test_knn_KPCA;
else if ntrain==total_datos
    Vec_TP_knn_error_pred_KPCA(iter_TP,1)=Error_knn_mean_KPCA;
    end
end
        

disp('Fin Clasifador KNN con KPCA');
   
%}

%% <<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>
%                  Clasificador de Parzen con KPCA
%<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


SigmaParzen_KPCA=0; 
SigmaParzenmax_KPCA=1.5;
iter_optim_Parzen_KPCA=15;
error_parzen_k_KPCA=NaN(iter_optim_Parzen_KPCA,3);


for k=1:iter_optim_Parzen_KPCA 
    
    SigmaParzen_KPCA=SigmaParzen_KPCA+SigmaParzenmax_KPCA/iter_optim_Parzen_KPCA; % Va aumentando el valor de sigma en cada iteraci�n
    
    error_val_parzen_KPCA=NaN(ntrain/nval,1);%Error en cada partici�n de validaci�n
    
    indice_particion=0;
    
      for idx_val=1:nval:ntrain; %Alterna la partici�n de validaci�n
          indice_particion=indice_particion+1;
                idx_val_min=idx_val;
                idx_val_max=idx_val+nval-1;
                rango_val=idx_val_min:idx_val_max;%Define el rango de validaci�n
                            
                % Ahora reparte los valores de Xtrain entre validaci�n y train restante
                       
                Xval=Xtrain_KPCA(rango_val,:);
                Yval=Ytrain_total(rango_val);
                
                Xtrain_res=Xtrain_KPCA;
                Xtrain_res(rango_val,:)=[];
                Ytrain_res=Ytrain_total;
                Ytrain_res(rango_val,:)=[];
                
                [labels_parzen_KPCA]=miParzen2(Xtrain_res,Ytrain_res,Xval,SigmaParzen_KPCA);
                               
                vec_diferencias_val_parzen_KPCA=labels_parzen_KPCA(:,1)-Yval(:);
                diferencias_parzen_KPCA=length(find(vec_diferencias_val_parzen_KPCA~=0));
                error_val_parzen_KPCA(indice_particion,1)=diferencias_parzen_KPCA/nval;
                                    
      end
      
        error_parzen_k_KPCA(k,1)=mean(error_val_parzen_KPCA(:,1));
        error_parzen_k_KPCA(k,2)=std(error_val_parzen_KPCA(:,1)); 
        error_parzen_k_KPCA(k,3)=SigmaParzen_KPCA;
    end
 
  
[Error_parzen_mean_KPCA,koptim_KPCA]=min(error_parzen_k_KPCA(:,1));
%Error_Parzen_Std_KPCA=error_parzen_k_KPCA(koptim_KPCA,2);
Sigma_optimo_parzen_KPCA=error_parzen_k_KPCA(koptim_KPCA,3);

Vec_TP_parzen_SimaOptim_KPCA(iter_TP,1)=Sigma_optimo_parzen_KPCA;

Vec_TP_parzen_error_val_KPCA(iter_TP,1)=Error_parzen_mean_KPCA;


if ~isempty(Ytest(:))

    labels_test_parzen_KPCA=miParzen2(Xtrain_KPCA,Ytrain_total,Xtest_KPCA,Sigma_optimo_parzen_KPCA);
        
    vec_diferencias_test_parzen_KPCA=labels_test_parzen_KPCA(:)-Ytest(:);
    diferencias_test_parzen_KPCA=length(find(vec_diferencias_test_parzen_KPCA~=0));
    error_test_parzen_KPCA=diferencias_test_parzen_KPCA/ntest; 

    Vec_TP_parzen_error_pred_KPCA(iter_TP,1)=error_test_parzen_KPCA;
else if ntrain==total_datos
        Vec_TP_parzen_error_pred_KPCA(iter_TP,1)=Error_parzen_mean_KPCA;
    end
end

disp('Fin Clasifador Parzen con KPCA');
      
    %}

%% <<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>
%                  Clasificador de Bayes con KPCA
%<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



%---------------------
%Discriminante lineal con KPCA
%---------------------

if ~isempty(Ytest(:))

    labels_disc_lineal_KPCA=midisclin(Xtrain_KPCA,Ytrain_total,Xtest_KPCA);

    vec_diferencias_test_disc_lineal_KPCA=labels_disc_lineal_KPCA(:)-Ytest(:);
    diferencias_test_disc_lineal_KPCA=length(find(vec_diferencias_test_disc_lineal_KPCA~=0));
    error_test_disc_lineal_KPCA=diferencias_test_disc_lineal_KPCA/ntest; 

    Vec_TP_disc_lin_error_pred_KPCA(iter_TP,1)=error_test_disc_lineal_KPCA;
else if ntrain==total_datos
        
    labels_disc_lineal_KPCA=midisclin(Xtrain_KPCA,Ytrain_total,Xtrain_KPCA);

    vec_diferencias_test_disc_lineal_KPCA=labels_disc_lineal_KPCA(:)-Ytrain_total(:);
    diferencias_test_disc_lineal_KPCA=length(find(vec_diferencias_test_disc_lineal_KPCA~=0));
    error_test_disc_lineal_KPCA=diferencias_test_disc_lineal_KPCA/ntrain; 

    Vec_TP_disc_lin_error_pred_KPCA(iter_TP,1)=error_test_disc_lineal_KPCA;
   
    end
end

%---------------------
%Discriminante cuadr�tico con KPCA
%---------------------

if ~isempty(Ytest(:))
    
    labels_disc_cuad_KPCA=midisccuad(Xtrain_KPCA,Ytrain_total,Xtest_KPCA);

    vec_diferencias_test_disc_cuad_KPCA=labels_disc_cuad_KPCA(:)-Ytest(:);
    diferencias_test_disc_cuad_KPCA=length(find(vec_diferencias_test_disc_cuad_KPCA~=0));
    error_test_disc_cuad_KPCA=diferencias_test_disc_cuad_KPCA/ntest; 

    Vec_TP_disc_cuad_error_pred_KPCA(iter_TP,1)=error_test_disc_cuad_KPCA;
else if ntrain==total_datos

    labels_disc_cuad_KPCA=midisccuad(Xtrain_KPCA,Ytrain_total,Xtrain_KPCA);

    vec_diferencias_test_disc_cuad_KPCA=labels_disc_cuad_KPCA(:)-Ytrain_total(:);
    diferencias_test_disc_cuad_KPCA=length(find(vec_diferencias_test_disc_cuad_KPCA~=0));
    error_test_disc_cuad_KPCA=diferencias_test_disc_cuad_KPCA/ntrain; 

    Vec_TP_disc_cuad_error_pred_KPCA(iter_TP,1)=error_test_disc_cuad_KPCA;
        
    end
end
disp('Fin Clasifador Bayes con KPCA');
   
%}
%% <<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>
%                  Clasificador SVM con KPCA
%<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


tipoKernel='gaussiano';

C_KPCA=0; %Define los rangos a evaluar de los par�metros C y "Par�metro del Kernel" 
Cmax_KPCA=2;
paramKernel_KPCA=0;
paramKernelmax_KPCA=2.5;
iteraciones_KPCA=10;
total_iteraciones_KPCA=iteraciones_KPCA*iteraciones_KPCA;

error_SVM_param_costo_KPCA=NaN(ntrain,ntrain,2);

for param=1:iteraciones_KPCA % Loop de optimizaci�n de paramKernel

    paramKernel_KPCA=paramKernel_KPCA+paramKernelmax_KPCA/ntrain;
    
    for costo=1:iteraciones_KPCA % Loop de optimizaci�n de C
        iteracion=iteraciones_KPCA*(param-1)+costo;
        C_KPCA=C_KPCA+Cmax_KPCA/ntrain; % Va aumentando el valor de sigma en cada iteraci�n

        error_val_SVM_KPCA=NaN(ntrain/nval,1);%Error en cada partici�n de validaci�n

        indice_particion=0;

          for idx_val=1:nval:ntrain; %Alterna la partici�n de validaci�n
              indice_particion=indice_particion+1;
                    idx_val_min=idx_val;
                    idx_val_max=idx_val+nval-1;
                    rango_val=idx_val_min:idx_val_max;%Define el rango de validaci�n

                    % Ahora reparte los valores de Xtrain entre validaci�n y train restante

                    Xval=Xtrain_KPCA(rango_val,:);
                    Yval=Ytrain_total(rango_val);

                    Xtrain_res=Xtrain_KPCA;
                    Xtrain_res(rango_val,:)=[];
                    Ytrain_res=Ytrain_total;
                    Ytrain_res(rango_val,:)=[];
                    
                    labels_svm_KPCA=miSVM2(Xtrain_res,Ytrain_res,Xval,tipoKernel,paramKernel_KPCA,C_KPCA);
                   
                    
                    vec_diferencias_val_SVM_KPCA=labels_svm_KPCA(:,1)-Yval(:);
                    diferencias_SVM_KPCA=length(find(vec_diferencias_val_SVM_KPCA~=0));
                    error_val_SVM_KPCA(indice_particion,1)=diferencias_SVM_KPCA/nval;

          end

            error_SVM_param_costo_KPCA(param,costo,1)=mean(error_val_SVM_KPCA(:,1));
            error_SVM_param_costo_KPCA(param,costo,2)=std(error_val_SVM_KPCA(:,1));
    %fprintf('Iteraci�n: ',iteracion,' de ',total_iteraciones_KPCA),
    end
end

[~,columna_optim_KPCA]=min(min(error_SVM_param_costo_KPCA(:,:,1)));
[~,fila_optim_KPCA]=min(min(error_SVM_param_costo_KPCA(:,:,1),[],2));

Error_SVM_optim_KPCA=error_SVM_param_costo_KPCA(fila_optim_KPCA,columna_optim_KPCA,1);
%Error_SVM_optim_StdDesv_KPCA=error_SVM_param_costo_KPCA(fila_optim_KPCA,columna_optim_KPCA,2);

C_optimo_KPCA=Cmax_KPCA/iteraciones_KPCA*columna_optim_KPCA;
Param_kernel_optim_KPCA=paramKernelmax_KPCA/iteraciones_KPCA*fila_optim_KPCA;
Vec_TP_SVM_Copt_KPCA(iter_TP,1)=C_optimo_KPCA;
Vec_TP_SVM_ParamKernelOptim_KPCA(iter_TP,1)=Param_kernel_optim_KPCA;

Vec_TP_SVM_error_val_KPCA(iter_TP,1)=Error_SVM_optim_KPCA;

if ~isempty(Ytest(:))
    
    labels_test_SVM_KPCA=miSVM2(Xtrain_KPCA,Ytrain_total,Xtest_KPCA,tipoKernel,Param_kernel_optim_KPCA,C_optimo_KPCA);
        
    vec_diferencias_test_SVM_KPCA=labels_test_SVM_KPCA(:)-Ytest(:);
    diferencias_test_SVM_KPCA=length(find(vec_diferencias_test_SVM_KPCA~=0));
    error_test_SVM_KPCA=diferencias_test_SVM_KPCA/ntest; 

    Vec_TP_SVM_error_pred_KPCA(iter_TP,1)=error_test_SVM_KPCA;
else if ntrain==total_datos
        
    Vec_TP_SVM_error_pred_KPCA(iter_TP,1)=Error_SVM_optim_KPCA;   
        
    end
end

disp('Fin Clasifador SVM con KPCA');
       
    %}

end

Resultados=table(Vec_TP_knn_error_pred,...
Vec_TP_knn_Koptim,...
Vec_TP_parzen_error_pred,...
Vec_TP_parzen_SimaOptim,...
Vec_TP_disc_lin_error_pred,...
Vec_TP_disc_cuad_error_pred,...
Vec_TP_SVM_error_pred,...
Vec_TP_SVM_Copt,...
Vec_TP_SVM_ParamKernelOptim,...
Vec_TP_knn_error_pred_KPCA,...
Vec_TP_knn_Koptim_KPCA,...
Vec_TP_parzen_error_pred_KPCA,...
Vec_TP_parzen_SimaOptim_KPCA,...
Vec_TP_disc_lin_error_pred_KPCA,...
Vec_TP_disc_cuad_error_pred_KPCA,...
Vec_TP_SVM_error_pred_KPCA,...
Vec_TP_SVM_Copt_KPCA,...
Vec_TP_SVM_ParamKernelOptim_KPCA,...
Vec_TP_knn_error_val,...
Vec_TP_parzen_error_val,...
Vec_TP_SVM_error_val,...
Vec_TP_lambda_KPCA,...
Vec_TP_knn_error_val_KPCA,...
Vec_TP_parzen_error_val_KPCA,...
Vec_TP_SVM_error_val_KPCA);
tiempo_este_tam_train=toc/60;
Texto_salida='Tama�o de muestra de entrenamiento';
Texto_tiempo='Tiempo de c�lculo [min]';
xlswrite(filename,{Texto_salida},iter_tam_ntrain,'A1');
xlswrite(filename,ntrain,iter_tam_ntrain,'D1');
xlswrite(filename,{Texto_tiempo},iter_tam_ntrain,'A2');
xlswrite(filename,tiempo_este_tam_train,iter_tam_ntrain,'D2');
writetable(Resultados,filename,'Sheet',iter_tam_ntrain,'Range','A5');

end

%% Alarma para avisar que termin�
%{
N=10000;
s=zeros(N,1);
for a=1:N
s(a)=tan(a); 
end

Fs=6000;

soundsc(s,Fs)
%}
disp('----------FIN-----------')