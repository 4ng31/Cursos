function [X,Xmax,Xmin]=minormalizador(Xorig,Xmax,Xmin)

X=NaN(size(Xorig));


if nargin~=3 % Si no ingreso Xmax, Xmin los toma de los datos.
    
    for i=1:length(Xorig(1,:))

        Xmax(i)=max(Xorig(:,i));
        Xmin(i)=min(Xorig(:,i));

    end;

end
for i=1:length(X(:,1))
    
    for j=1:length(X(1,:))
        
        X(i,j)=(Xorig(i,j)-Xmin(j))/(Xmax(j)-Xmin(j));
        
    end
    
end


end