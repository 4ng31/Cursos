function [labels]=miKNN2(Xtrain,Ytrain,Xval,K)

[D,I]=pdist2(Xtrain,Xval,'euclidean','smallest',K);

labels=NaN(length(Xval(:,1)),1);

for n=1:length(labels);
    labels(n)=mode(Ytrain(I(:,n)));
end
     

end