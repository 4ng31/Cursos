function [X_KPCA,v,lambda] = miKPCA(Xtrain,tipoKernelPCA,param,d,Xtest)

if nargin < 5,
    Xtest = Xtrain;
end

[n,p] = size(Xtrain);
d = min(d,n);

Matriz_Kernel = zeros(n);

switch lower(tipoKernelPCA)
    case 'sin kernel'
        for i=1:n,
            for j=1:i,
                Matriz_Kernel(i,j) = Xtrain(i,:)*Xtrain(j,:)';
                Matriz_Kernel(j,i) = Matriz_Kernel(i,j);
            end
        end
    case 'gaussiano'
        for i=1:n,
            for j=1:i,
                dif_PCA=norm(Xtrain(i,:)-Xtrain(j,:));
                Matriz_Kernel(i,j) = (exp(-0.5*(dif_PCA*dif_PCA')/(param^2)));
                Matriz_Kernel(j,i) = Matriz_Kernel(i,j);
            end
        end
    case 'polinomico'
        for i=1:n,
            for j=1:i,
               
                Matriz_Kernel(i,j) = (1+Xtrain(i,:)-Xtrain(j,:)')^param;
                Matriz_Kernel(j,i) = Matriz_Kernel(i,j);
            end
        end   
end


unos = ones(n)/n; % Centramos la matriz
Matriz_Kernel_centrada = Matriz_Kernel-unos*Matriz_Kernel-Matriz_Kernel*unos+unos*Matriz_Kernel*unos;

[a,lambda] = eig(Matriz_Kernel_centrada); % Encontramos las direcciones principales
lambda = diag(lambda);
[lambda,idx] = sort(lambda,'descend');
a = a(:,idx);
v = a(:,1:d);
for j=1:d,
    v(:,j) = a(:,j)/sqrt(lambda(j));
end

[ntest,p] = size(Xtest); %Ahora proyectamos los datos de test sobre las direcciones principales
Matriz_Kernel_Test = zeros(ntest,n);

switch lower(tipoKernelPCA)
    case 'sin kernel'
        for i=1:ntest
            for j=1:n
                Matriz_Kernel_Test(i,j) = Xtest(i,:)*Xtrain(j,:)';
            end
        end
    case 'gaussiano'
        for i=1:ntest
            for j=1:n
                dif_PCA=norm(Xtest(i,:)-Xtrain(j,:));
                Matriz_Kernel_Test(i,j) = (exp(-0.5*(dif_PCA*dif_PCA')/(param^2)));
            end
        end
    case 'polinomico'
        for i=1:ntest
            for j=1:n
               
                Matriz_Kernel_Test(i,j) = (1+Xtest(i,:)-Xtrain(j,:)')^param;
                
            end
        end   
end


unos_test = ones(ntest,n)/n;

Matriz_Kernel_Test_centr = Matriz_Kernel_Test - unos_test*Matriz_Kernel - Matriz_Kernel_Test*unos + unos_test*Matriz_Kernel*unos; %Centramos la Matriz

X_KPCA = Matriz_Kernel_Test_centr*v;

end